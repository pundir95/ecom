const errroMiddelware = (err, req, res, next) => {

    // res.status(500).json(err)

    const defaultErrors = {
        statusCode: 500,
        message: err,
    };
    // missing filed error
    if (err.name === "ValidationError") {
        defaultErrors.statusCode = 400;
        defaultErrors.message = Object.values(err.errors)
            .map((item) => item.message)
            .join(",");
    }
    // if (err.code && err.code === 11000) {
    //     defaultErrors.statusCode = 400;
    //     defaultErrors.message = `${Object.keys(
    //         err.keyValue
    //     )} field has to be unique`;
    // }

    res.status(400).json({ message: defaultErrors.message, status: 400 });
}

export default errroMiddelware